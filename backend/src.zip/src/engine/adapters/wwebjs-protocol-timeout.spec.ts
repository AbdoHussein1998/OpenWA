



import { Callback } from 'puppeteer-core/lib/cjs/puppeteer/common/CallbackRegistry.js';
import { Client } from 'whatsapp-web.js';
import configuration, { MAX_TIMER_MS } from '../../config/configuration';
import { validateEnv } from '../../config/env.validation';
import { WhatsAppWebJsAdapter } from './whatsapp-web-js.adapter';
import type { BraveProfileManager } from '../brave/brave-profile.manager';

/**
 * The per-CDP-command budget handed to Puppeteer, and the one error it produces.
 *
 * Three invariants worth pinning: the value is range-checked before it leaves the config layer,
 * the option reaches the Client when set and is absent when not, and a protocol timeout is never
 * read as a dead page. The death signatures themselves are covered in whatsapp-web-js.adapter.spec.
 */
describe('whatsapp-web.js protocol timeout', () => {
  const SESSION_ID = 'sess-protocol-timeout';
  let clientInitSpy: jest.SpyInstance;
  let savedWebVersion: string | undefined;

  /**
   * This suite verifies protocol-timeout plumbing, not Brave process management.
   *
   * The real BraveProfileManager performs OS-level process discovery during initialize()
   * (PowerShell/CIM on Windows), which turns this focused unit test into a slow integration
   * test and can exceed Jest's default 5-second per-test budget when several adapters are
   * initialized sequentially.
   *
   * Keep the lifecycle path intact, but replace those unrelated side effects with immediate
   * successful test doubles.
   */
  const braveProfileManager = {
    getProfilePath: jest.fn((sessionId: string) => `./data/brave-profiles/${sessionId}`),
    ensureProfile: jest.fn().mockResolvedValue(undefined),
    acquireProfileLease: jest.fn().mockResolvedValue(
      Object.assign(async () => undefined, { ownerToken: '00000000-0000-4000-8000-000000000001' }),
    ),
    killOrphanedBraveProcesses: jest.fn().mockResolvedValue(undefined),
    removeStaleSingletonFiles: jest.fn().mockResolvedValue(undefined),
  } as unknown as BraveProfileManager;

  const launchedPuppeteerOptions = async (
    protocolTimeoutMs?: number,
  ): Promise<{ protocolTimeout?: number; args?: string[] } | undefined> => {
    const adapter = new WhatsAppWebJsAdapter({
      sessionId: SESSION_ID,
      sessionDataPath: './data/sessions',
      puppeteer: { protocolTimeoutMs },

      // resolveBraveExecutable() validates configured paths before accepting them.
      // process.execPath is guaranteed to exist on the running Node process.
      //
      // Client.initialize() is mocked below, so Node is NEVER actually launched as
      // a browser; this only lets the lifecycle reach Client construction immediately.
      brave: {
        executablePath: process.execPath,
      },

      braveProfileManager,
    });

    await adapter.initialize({});

    return (
      adapter as unknown as {
        client: {
          options: {
            puppeteer?: {
              protocolTimeout?: number;
              args?: string[];
            };
          };
        };
      }
    ).client.options.puppeteer;
  };

  beforeEach(() => {
    // Keep initialize() offline: 'off' skips the wa-version registry fetch in resolveWebVersionPin.
    savedWebVersion = process.env.WWEBJS_WEB_VERSION;
    process.env.WWEBJS_WEB_VERSION = 'off';

    // Build the real whatsapp-web.js Client — that is what carries the launch options —
    // but launch no browser.
    clientInitSpy = jest
      .spyOn(
        Client.prototype as unknown as {
          initialize: () => Promise<void>;
        },
        'initialize',
      )
      .mockResolvedValue(undefined);
  });

  afterEach(() => {
    clientInitSpy.mockRestore();

    if (savedWebVersion === undefined) {
      delete process.env.WWEBJS_WEB_VERSION;
    } else {
      process.env.WWEBJS_WEB_VERSION = savedWebVersion;
    }
  });

  it('tags the launched Brave browser with the exact filesystem lease generation', async () => {
    const options = await launchedPuppeteerOptions();
    expect(options?.args).toContain('--al-hakim-lease=00000000-0000-4000-8000-000000000001');
    expect(options?.args).toContain('--al-hakim-session=sess-protocol-timeout');
  });

  it('hands a configured budget to the Client as puppeteer.protocolTimeout', async () => {
    expect(await launchedPuppeteerOptions(300_000)).toMatchObject({
      protocolTimeout: 300_000,
    });
  });

  it('omits the option when unset, leaving Puppeteer its own default', async () => {
    const options = await launchedPuppeteerOptions(undefined);

    // Truly absent: `toHaveProperty` passes on a present-but-undefined key, so this is the check
    // that the option was never spread rather than spread as undefined.
    expect(options).not.toHaveProperty('protocolTimeout');
  });

  it('omits the option for a value configuration.ts would never produce', async () => {
    // The config layer is not the only writer: a plugin config (PUT /api/plugins/{id}/config) is
    // validated as an object and merged over the env blob at boot, so the sink enforces the bounds
    // too. 0 arms no timer at all; over MAX_TIMER_MS overflows Node's and fires after 1 ms.
    expect(await launchedPuppeteerOptions(0)).not.toHaveProperty('protocolTimeout');
    expect(await launchedPuppeteerOptions(-1)).not.toHaveProperty('protocolTimeout');
    expect(await launchedPuppeteerOptions(MAX_TIMER_MS + 1)).not.toHaveProperty('protocolTimeout');
    expect(await launchedPuppeteerOptions(MAX_TIMER_MS)).toMatchObject({
      protocolTimeout: MAX_TIMER_MS,
    });
  });

  describe('the bounds this knob exists to enforce', () => {
    it('rejects a non-positive or over-range value at boot instead of handing it to Puppeteer', () => {
      expect(() =>
        validateEnv({
          PUPPETEER_PROTOCOL_TIMEOUT_MS: '0',
        }),
      ).toThrow(/positive integer/);

      expect(() =>
        validateEnv({
          PUPPETEER_PROTOCOL_TIMEOUT_MS: '-1',
        }),
      ).toThrow(/positive integer/);

      expect(() =>
        validateEnv({
          PUPPETEER_PROTOCOL_TIMEOUT_MS: 'abc',
        }),
      ).toThrow(/positive integer/);

      // The row of nines an operator reaches for when the docs forbid 0.
      expect(() =>
        validateEnv({
          PUPPETEER_PROTOCOL_TIMEOUT_MS: String(MAX_TIMER_MS + 1),
        }),
      ).toThrow(/must not exceed/);

      expect(() =>
        validateEnv({
          PUPPETEER_PROTOCOL_TIMEOUT_MS: '999999999999',
        }),
      ).toThrow(/must not exceed/);

      expect(() =>
        validateEnv({
          PUPPETEER_PROTOCOL_TIMEOUT_MS: String(MAX_TIMER_MS),
        }),
      ).not.toThrow();

      expect(() =>
        validateEnv({
          PUPPETEER_PROTOCOL_TIMEOUT_MS: '300000',
        }),
      ).not.toThrow();
    });

    it('leaves the option unset for anything out of range, never falsy', () => {
      const parsed = (raw?: string): number | undefined => {
        const saved = process.env.PUPPETEER_PROTOCOL_TIMEOUT_MS;

        if (raw === undefined) {
          delete process.env.PUPPETEER_PROTOCOL_TIMEOUT_MS;
        } else {
          process.env.PUPPETEER_PROTOCOL_TIMEOUT_MS = raw;
        }

        try {
          return (
            configuration() as {
              engine: {
                puppeteer: {
                  protocolTimeoutMs?: number;
                };
              };
            }
          ).engine.puppeteer.protocolTimeoutMs;
        } finally {
          if (saved === undefined) {
            delete process.env.PUPPETEER_PROTOCOL_TIMEOUT_MS;
          } else {
            process.env.PUPPETEER_PROTOCOL_TIMEOUT_MS = saved;
          }
        }
      };

      // A blank compose forward is "unset", not 0.
      expect(parsed(undefined)).toBeUndefined();
      expect(parsed('')).toBeUndefined();
      expect(parsed('0')).toBeUndefined();
      expect(parsed('-1')).toBeUndefined();
      expect(parsed('abc')).toBeUndefined();
      expect(parsed(String(MAX_TIMER_MS + 1))).toBeUndefined();
      expect(parsed('300000')).toBe(300_000);
      expect(parsed(String(MAX_TIMER_MS))).toBe(MAX_TIMER_MS);
    });
  });

  describe('the transport classifier', () => {
    const classify = (message: string): boolean => {
      const adapter = new WhatsAppWebJsAdapter({
        sessionId: SESSION_ID,
        sessionDataPath: './data/sessions',
        puppeteer: {},

        // This adapter is never initialized, but keep construction aligned with the
        // current required WhatsAppWebJsConfig shape.
        brave: {
          executablePath: process.execPath,
        },

        braveProfileManager,
      });

      return (
        adapter as unknown as {
          isPageTransportError: (error: unknown) => boolean;
        }
      ).isPageTransportError(new Error(message));
    };

    /**
     * Provoked from the INSTALLED puppeteer-core rather than copied from it. The guard exists to
     * survive a message the library may reshape on a version bump, so a hand-written literal would
     * keep passing while the real string drifted out from under it — the one drift this test is
     * here to catch. Driving the real `Callback` is also what shows the label is the bare CDP
     * method name, with no `Protocol error (...)` prefix for the death pattern to match.
     */
    const puppeteerProtocolTimeoutMessage = async (): Promise<string> => {
      const callback = new Callback(1, 'Runtime.callFunctionOn', 1);

      try {
        await callback.promise;
      } catch (error) {
        return error instanceof Error ? error.message : String(error);
      }

      throw new Error('puppeteer-core did not reject on an expired protocolTimeout');
    };

    it('does not treat a protocol timeout as a dead page', async () => {
      const message = await puppeteerProtocolTimeoutMessage();

      // Guard the guard: if a bump ever drops the phrase this classifier keys on, fail here rather
      // than silently start reporting slow reads as deaths.
      expect(message).toMatch(/timed out\. Increase the 'protocolTimeout'/);
      expect(classify(message)).toBe(false);

      // The case that makes the carve-out load-bearing rather than decorative: puppeteer's own
      // `_reject` formats a rejected command as `Protocol error (label): message`, which the death
      // pattern matches. Without the carve-out this reads as a dead page.
      expect(classify(`Protocol error (Runtime.callFunctionOn): ${message}`)).toBe(false);
    });

    it('reports a death whose message also mentions a timeout', () => {
      // Why the guard matches Puppeteer's full phrase instead of a bare /timed out/: the broad
      // version swallows this, turning a reportable dead page into a silent one.
      expect(
        classify(
          'Protocol error (Runtime.callFunctionOn): Session closed. Request timed out',
        ),
      ).toBe(true);
    });
  });
});




