import { useTranslation } from 'react-i18next';
import {
  AlertCircle,
  CircleDashed,
  Loader2,
  Megaphone,
  Plus,
  Search,
} from 'lucide-react';
import type { UseQueryResult } from '@tanstack/react-query';
import type {
  Channel,
  Chat,
  ContactStatusGroup,
  Session,
} from '../../services/api';
import ChatAvatar from './ChatAvatar';

export type ChatsTab = 'chats' | 'channels' | 'status';

interface ChatSidebarProps {
  sessions: Session[];

  selectedSessionId: string;

  /**
   * Existing Chats page uses this to change the active session.
   *
   * In lockedSession mode, the callback is still accepted for backward
   * compatibility but the session selector is not rendered.
   */
  onSelectSession: (sessionId: string) => void;

  /**
   * Optional SPG mode.
   *
   * false / undefined:
   *   Existing Chats behavior. User can switch sessions.
   *
   * true:
   *   Session is locked to selectedSessionId and the session selector
   *   is hidden.
   */
  lockedSession?: boolean;

  activeTab: ChatsTab;
  onSwitchTab: (tab: ChatsTab) => void;

  searchQuery: string;
  onSearchQueryChange: (query: string) => void;

  onComposeStatus: () => void;

  formatChatTime: (timestamp?: number) => string;

  chatsTab: {
    loading: boolean;
    chats: Chat[];
    activeChatId?: string;
    pictures?: Record<string, string | null>;
    onSelectChat: (chat: Chat) => void;
  };

  channelsTab: {
    engineLoading: boolean;
    supported: boolean;
    query: UseQueryResult<Channel[], Error>;
    channels: Channel[];
    activeChannelId?: string;
    onSelectChannel: (channel: Channel) => void;
  };

  statusTab: {
    loading: boolean;
    error: boolean;
    groups: ContactStatusGroup[];
    activeContactId: string | null;
    onSelectContact: (contactId: string) => void;
  };
}

// LEFT SIDEBAR:
// - session selector when unlocked
// - Chats / Channels / Status tab bar
// - search
// - per-tab lists
//
// The page owns all queries/state; this component renders them and reports
// interactions up.
//
// `lockedSession` is optional so the normal Chats page keeps its existing
// behavior unchanged.
function ChatSidebar({
  sessions,
  selectedSessionId,
  onSelectSession,
  lockedSession = false,
  activeTab,
  onSwitchTab,
  searchQuery,
  onSearchQueryChange,
  onComposeStatus,
  formatChatTime,
  chatsTab,
  channelsTab,
  statusTab,
}: ChatSidebarProps) {
  const { t } = useTranslation();

  const formatLastMessageSnippet = (chat: Chat) => chat.lastMessage || '';

  // Shared row markup for the Chats and Status lists.
  const renderChatRow = (chat: Chat) => {
    const isActive = chatsTab.activeChatId === chat.id;

    return (
      <div
        key={chat.id}
        role="button"
        tabIndex={0}
        aria-current={isActive ? 'true' : undefined}
        className={`chat-item-card ${isActive ? 'active' : ''}`}
        onClick={() => chatsTab.onSelectChat(chat)}
        onKeyDown={e => {
          if (e.key === 'Enter' || e.key === ' ') {
            e.preventDefault();
            chatsTab.onSelectChat(chat);
          }
        }}
      >
        <ChatAvatar
          pictureUrl={chatsTab.pictures?.[chat.id]}
          kind={chat.kind}
        />

        <div className="chat-item-info">
          <div className="chat-item-top">
            <span
              className="chat-item-name"
              title={chat.name || chat.id}
            >
              {chat.name || chat.id.split('@')[0]}
            </span>

            {chat.kind !== 'individual' && chat.kind !== 'unknown' && (
              <span className={`chat-kind-badge kind-${chat.kind}`}>
                {t(`chats.kind.${chat.kind}`)}
              </span>
            )}

            {chat.timestamp ? (
              <span className="chat-item-time">
                {formatChatTime(chat.timestamp)}
              </span>
            ) : null}
          </div>

          <div className="chat-item-bottom">
            <span
              className="chat-item-snippet"
              title={formatLastMessageSnippet(chat)}
            >
              {formatLastMessageSnippet(chat) || (
                <span className="no-message">
                  {t('chats.noMessageYet')}
                </span>
              )}
            </span>

            {chat.unreadCount > 0 && (
              <span
                className="chat-unread-badge"
                title={t('chats.unreadBadge', {
                  count: chat.unreadCount,
                })}
                aria-label={t('chats.unreadBadge', {
                  count: chat.unreadCount,
                })}
              >
                {chat.unreadCount > 99 ? '99+' : chat.unreadCount}
              </span>
            )}
          </div>
        </div>
      </div>
    );
  };

  return (
    <aside className="chats-sidebar">
      <div className="sidebar-header-box">
        {/* ============================================================
            SESSION SELECTOR

            Existing Chats page:
              lockedSession === false
                -> render the normal session selector.

            SPG:
              lockedSession === true
                -> do not render selector.
            ============================================================ */}
        {!lockedSession && (
          <div className="session-select-group">
            <label className="form-label" htmlFor="csb-1">
              {t('chats.sessionLabel')}
            </label>

            <select
              id="csb-1"
              value={selectedSessionId}
              onChange={e => onSelectSession(e.target.value)}
              className="session-selector"
            >
              {sessions.map(s => (
                <option key={s.id} value={s.id}>
                  {s.name} ({s.phone || t('chats.noPhone')})
                </option>
              ))}
            </select>
          </div>
        )}

        {/* ============================================================
            CHATS / CHANNELS / STATUS
            ============================================================ */}
        <div className="chats-tabs" role="tablist">
          {(['chats', 'channels', 'status'] as const).map(tab => (
            <button
              key={tab}
              type="button"
              role="tab"
              aria-selected={activeTab === tab}
              className={`chats-tab ${
                activeTab === tab ? 'active' : ''
              }`}
              onClick={() => onSwitchTab(tab)}
            >
              {t(`chats.tab.${tab}`)}
            </button>
          ))}
        </div>

        {/* ============================================================
            SEARCH
            ============================================================ */}
        <div className="chat-search-input">
          <Search size={18} />

          <input
            type="text"
            placeholder={t('chats.searchPlaceholder')}
            value={searchQuery}
            onChange={e => onSearchQueryChange(e.target.value)}
          />
        </div>

        {/* ============================================================
            STATUS COMPOSE
            ============================================================ */}
        {activeTab === 'status' && (
          <button
            type="button"
            className="btn-primary status-compose-trigger"
            onClick={onComposeStatus}
          >
            <Plus size={16} />
            {t('chats.status.compose')}
          </button>
        )}
      </div>

      {/* ================================================================
          CHAT LIST
          ================================================================ */}
      {activeTab === 'chats' && (
        <div className="chats-list">
          {chatsTab.loading ? (
            <div className="chats-list-loading">
              <Loader2 className="animate-spin" size={24} />
              <span>{t('chats.loadingChats')}</span>
            </div>
          ) : chatsTab.chats.length === 0 ? (
            <div className="chats-list-empty">
              <span>{t('chats.empty')}</span>
            </div>
          ) : (
            chatsTab.chats.map(renderChatRow)
          )}
        </div>
      )}

      {/* ================================================================
          CHANNELS LIST
          ================================================================ */}
      {activeTab === 'channels' && (
        <div className="chats-list">
          {channelsTab.engineLoading ? (
            <div className="chats-list-loading">
              <Loader2 className="animate-spin" size={24} />
            </div>
          ) : !channelsTab.supported ? (
            <div className="chats-list-empty">
              <span>{t('chats.channels.notSupported')}</span>
            </div>
          ) : channelsTab.query.isLoading ? (
            <div className="chats-list-loading">
              <Loader2 className="animate-spin" size={24} />
            </div>
          ) : channelsTab.query.error ? (
            <div className="chats-list-empty">
              <AlertCircle size={24} className="text-warn" />
              <span>{t('chats.channels.notReady')}</span>
            </div>
          ) : (channelsTab.query.data?.length ?? 0) === 0 ? (
            <div className="chats-list-empty">
              <span>{t('chats.channels.empty')}</span>
            </div>
          ) : (
            channelsTab.channels.map(ch => (
              <div
                key={ch.id}
                role="button"
                tabIndex={0}
                aria-current={
                  channelsTab.activeChannelId === ch.id
                    ? 'true'
                    : undefined
                }
                className={`chat-item-card ${
                  channelsTab.activeChannelId === ch.id
                    ? 'active'
                    : ''
                }`}
                onClick={() => channelsTab.onSelectChannel(ch)}
                onKeyDown={e => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    channelsTab.onSelectChannel(ch);
                  }
                }}
              >
                <div className="chat-avatar">
                  <Megaphone size={20} />
                </div>

                <div className="chat-item-info">
                  <div className="chat-item-top">
                    <span className="chat-item-name">
                      {ch.name}
                    </span>
                  </div>

                  {ch.subscriberCount != null && (
                    <div className="chat-item-bottom">
                      <span className="chat-item-snippet">
                        {t('chats.channels.subscribers', {
                          count: ch.subscriberCount,
                        })}
                      </span>
                    </div>
                  )}
                </div>
              </div>
            ))
          )}
        </div>
      )}

      {/* ================================================================
          STATUS LIST
          ================================================================ */}
      {activeTab === 'status' && (
        <div className="chats-list">
          {statusTab.loading ? (
            <div className="chats-list-loading">
              <Loader2 className="animate-spin" size={24} />
            </div>
          ) : statusTab.error ? (
            <div className="chats-list-empty">
              <AlertCircle size={24} className="text-warn" />
              <span>{t('chats.status.loadError')}</span>
            </div>
          ) : statusTab.groups.length === 0 ? (
            <div className="chats-list-empty">
              <span>{t('chats.status.empty')}</span>
            </div>
          ) : (
            statusTab.groups.map(group => (
              <div
                key={group.contact.id}
                role="button"
                tabIndex={0}
                aria-current={
                  statusTab.activeContactId === group.contact.id
                    ? 'true'
                    : undefined
                }
                className={`chat-item-card ${
                  statusTab.activeContactId === group.contact.id
                    ? 'active'
                    : ''
                }`}
                onClick={() =>
                  statusTab.onSelectContact(group.contact.id)
                }
                onKeyDown={e => {
                  if (e.key === 'Enter' || e.key === ' ') {
                    e.preventDefault();
                    statusTab.onSelectContact(group.contact.id);
                  }
                }}
              >
                <div className="chat-avatar">
                  <CircleDashed size={20} />
                </div>

                <div className="chat-item-info">
                  <div className="chat-item-top">
                    <span className="chat-item-name">
                      {group.contact.name ??
                        group.contact.pushName ??
                        group.contact.id}
                    </span>

                    <span className="chat-item-time">
                      {formatChatTime(
                        Math.floor(
                          new Date(group.latest).getTime() /
                            1000,
                        ),
                      )}
                    </span>
                  </div>

                  <div className="chat-item-bottom">
                    <span className="chat-item-snippet">
                      {t('chats.status.itemCount', {
                        count: group.items.length,
                      })}
                    </span>
                  </div>
                </div>
              </div>
            ))
          )}
        </div>
      )}
    </aside>
  );
}

export default ChatSidebar;